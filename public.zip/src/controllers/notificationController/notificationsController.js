const {
  sentNotificationToMultipleUsers,
  sendNotificationToSingleUser,
} = require("../../config/expo-push-notification/expoNotification");
const {
  customeNoticationModel,
} = require("../../models/contactYourAdvocateModel");
const fcmTokenModel = require("../../models/fcmTokenModel");
const NotificationModel = require("../../models/NotificationModel");

// add notification
exports.createNotification = async (userId, title, message, type) => {
  console.log({ userId, title, message, type });
  return await NotificationModel.create({
    userId,
    title,
    message,
    type,
  });
};

// ✅ Get all notifications for a user
exports.getUserNotifications = async (req, res) => {
  try {
    const { user_id } = req; // from auth middleware
    const notifications = await NotificationModel.find({
      userId: user_id,
    }).sort({
      createdAt: -1,
    });

    res.status(200).json({
      success: true,
      count: notifications.length,
      notifications,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ✅ Mark single notification as read
exports.markAsRead = async (req, res) => {
  try {
    const { id } = req.params;
    const { user_id } = req;

    const notification = await NotificationModel.findOneAndUpdate(
      { _id: id, userId: user_id },
      { isRead: true },
      { new: true }
    );

    if (!notification) {
      return res.status(404).json({ success: false, message: "Not found" });
    }

    res.status(200).json({ success: true, notification });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ✅ Mark all as read
exports.markAllAsRead = async (req, res) => {
  try {
    const { user_id } = req;
    await NotificationModel.updateMany({ userId: user_id }, { isRead: true });
    res
      .status(200)
      .json({ success: true, message: "All notifications marked as read" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ✅ Delete notification
exports.deleteNotification = async (req, res) => {
  try {
    const { id } = req.params;
    const { user_id } = req;

    const deleted = await NotificationModel.findOneAndDelete({
      _id: id,
      userId: user_id,
    });
    if (!deleted) {
      return res.status(404).json({ success: false, message: "Not found" });
    }

    res.status(200).json({ success: true, message: "Notification deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.insertManyNotification = async (userIds, title, message, type) => {
  try {
    if (!userIds || userIds.length === 0) {
      return { success: false, message: "No UserIds provide" };
    }
    const notifications = userIds.map((_id) => ({
      userId: _id,
      title,
      message,
      type,
    }));

    const result = await NotificationModel.insertMany(notifications);
    return { success: true, message: "Insert success", count: result.length };
  } catch (error) {
    console.error("Error inserting notifications:", error);
    return { success: false, message: error.message };
  }
};
exports.sendNotificationToAll = async (req, res) => {
  try {
    const { message } = req.body;
    if (!message || message == "" || message.length === 0) {
      return res
        .status(400)
        .json({ success: false, message: "message required" });
    }
    const expo_tokens = await fcmTokenModel.find({});
    const tokens = [],
      userIds = [];
    expo_tokens.forEach((e) => tokens.push(e.token));
    expo_tokens.forEach((e) => userIds.push(e.userId));
    await sentNotificationToMultipleUsers(tokens, message);
    await this.insertManyNotification(
      userIds,
      "Debt Relief India",
      message,
      "all"
    );
    return res
      .status(200)
      .json({ success: true, message: "notification send" });
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: error.message, error });
  }
};

// insert many notiifications

//  custom notification by admin
exports.customeNotification = async (req, res) => {
  try {
    const { message, type } = req.body;

    if (!message || message.length === 0) {
      return res.status(400).json({
        success: false,
        message: "message missing",
      });
    }
    const updateFields = {};
    if (type === "submit") {
      updateFields["kyc_submit"] = message;
    } else if (type === "approve") {
      updateFields["kyc_approve"] = message;
    } else if (type === "invoice") {
      updateFields["invoice"] = message;
    } else if (type === "reminder")
      updateFields["reminder_notification"] = message;
    else if (type === "emi") updateFields["Emi_Notification"] = message;
    else {
      return res
        .status(400)
        .json({ success: false, message: "Invalid notification type" });
    }
    const setupMessage = await customeNoticationModel.findOneAndUpdate(
      {},
      { $set: updateFields },
      { new: true, upsert: true }
    );

    if (!setupMessage) {
      return res.status(400).json({
        success: false,
        message: "failed to setup message",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Notification setup successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: error.message,
      error,
    });
  }
};

//get custom notifiation
exports.getCustomNotification = async (req, res) => {
  try {
    const data = await customeNoticationModel.find({});
    return res.status(200).json({ success: true, data: data });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
      error,
    });
  }
};

exports.sendSingleUserNotification = async (req, res, next) => {
  const requriedField = ["id", "title", "message", "subtitle", "type"];

  for (let fields of requriedField) {
    if (!req.body[fields] || req.body[fields].toString().trim().length === 0) {
      return res.status(400).json({
        statu: false,
        message: `${fields} Missing`,
      });
    }
  }
  const { id, title, message, subtitle, type } = req.body;
  const getToken = await fcmTokenModel.findOne({ userId: id });
  const createNotific = await this.createNotification(
    id,
    title,
    message,
    type,
    subtitle
  );
  const send = await sendNotificationToSingleUser(
    getToken.token,
    message,
    title,
    type,
    subtitle
  );

  if (send.success) {
    return res.status(200).json({
      status: true,
      message: "Notification send",
    });
  } else {
    return res.statu(400).json({
      status: false,
      message: "Failed to send",
    });
  }
};
