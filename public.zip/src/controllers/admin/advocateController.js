const { default: mongoose } = require("mongoose");
const adminModel = require("../../models/adminModel");
const advocateModel = require("../../models/advocateModel");
const cloudinay = require("../../utilitis/cloudinary");
const fs = require("fs");
const { serviceTimingModel } = require("../../models/contactYourAdvocateModel");
exports.addAdvocate = async (req, res, next) => {
  try {
    const imagePath = req.file;
    const { name, contactNumber } = req.body;
    if (!name || !contactNumber || !imagePath)
      return res
        .status(400)
        .json({ success: false, message: "Advocate Credentials Missing" });
    const payload = { name, contactNumber };
    payload.advocateImage = imagePath.location;
    payload.imagePublicKey = imagePath.key; // public key for delete imaget to cloudinary
    const createAdvocate = await advocateModel.create(payload);
    if (!createAdvocate) {
      return res
        .status(400)
        .json({ success: false, message: "failed to add Advocate" });
    }
    return res
      .status(200)
      .json({ success: true, message: "added successfully" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: error.message });
  }
};

// update timing
exports.updateAdvocate = async (req, res, next) => {
  try {
    const { admin_id } = req;
    const imagePath = req.file; // uploaded file
    const { name, contact, id } = req.body;

    console.log("path", imagePath);

    if (!admin_id) return res.status(401).json({ message: "Admin id missing" });

    if (!mongoose.Types.ObjectId.isValid(admin_id))
      return res
        .status(400)
        .json({ success: false, message: "Admin Id should be ObjectId" });

    if (!id)
      return res
        .status(400)
        .json({ success: false, message: "Advocate Id required" });

    if (!mongoose.Types.ObjectId.isValid(id))
      return res
        .status(400)
        .json({ success: false, message: "Advocate Id must be ObjectId" });

    if (!name || !contact)
      return res
        .status(400)
        .json({ success: false, message: "Advocate credentials missing" });

    const isAdvocate = await advocateModel.findById(id);
    if (!isAdvocate)
      return res
        .status(404)
        .json({ success: false, message: "Advocate not found" });

    const payload = {
      name,
      contactNumber: contact,
      advocateImage: imagePath?.location || isAdvocate.advocateImage,
      imagePublicKey: imagePath?.key || isAdvocate.imagePublicKey,
    };

    await isAdvocate.updateOne(payload);

    return res.status(200).json({ success: true, message: "Profile Updated" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message, success: false });
  }
};

// single advocate profile get
exports.getSingleAdvocate = async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res
        .status(200)
        .json({ success: false, message: "Advocate id must be ObjectId" });
    }
    const advocate = await advocateModel.findById(id);
    if (!advocate) {
      return res
        .status(404)
        .json({ success: false, message: "Advocate Not Found" });
    }
    if (advocate.isDelete === true) {
      return res
        .status(400)
        .json({ success: false, messae: "Advocate not available" });
    }
    return res.status(200).json({ success: true, data: advocate });
  } catch (error) {
    return res.status(500).json({ message: error.message, success: false });
  }
};

// get all advocates
exports.getAllAdvocates = async (req, res, next) => {
  try {
    const advocates = await advocateModel.find({ isDelete: { $ne: true } });
    if (!advocates) {
      return res
        .status(404)
        .json({ success: false, message: "No advocates found" });
    }
    return res.status(200).json({ success: true, data: advocates });
  } catch (error) {
    return res.status(500).json({ message: error.message, success: false });
  }
};

// service timeing
exports.serviceTiming = async (req, res) => {
  try {
    const { timing } = req.body;
    if (!timing) {
      return res
        .status(400)
        .json({ success: false, message: "timing credentials missing" });
    }
    const set_timing = await serviceTimingModel.findOneAndUpdate(
      {},
      { timing },
      { upsert: true, new: true }
    );
    if (!set_timing) {
      return res
        .status(400)
        .json({ success: false, message: "Faild to set timing" });
    }
    return res.json({
      success: true,
      message: "service timing added`",
    });
  } catch (error) {
    return res.status(500).json({ message: error.message, success: false });
  }
};

exports.getAdvocateTiming = async (req, res, next) => {
  try {
    const timing = await serviceTimingModel.find({});
    return res.status(200).json({ success: true, timing });
  } catch (error) {
    return res.status(500).json({ message: error.message, success: false });
  }
};

// advocate delete
exports.deleteAdvocate = async (req, res, next) => {
  try {
    const validation = { admin_id: "", id: "" };
    const { admin_id } = req;
    const { id } = req.params;
    Object.keys(validation).forEach((key) => {
      if (!req[key] && !req.params[key] && !req.query[key] && !req.body[key]) {
        console.log(`${key} is missing`);
      }
    });
    const isAdmin = await adminModel.findById(admin_id);
    if (!isAdmin) {
      return res
        .status(400)
        .json({ success: false, message: "Un-authorized Admin" });
    }
    const isAdvocate = await advocateModel.findOneAndUpdate(
      { _id: id },
      { $set: { isDelete: true } }
    );
    if (!isAdvocate) {
      return res
        .status(400)
        .json({ success: false, message: "Failed to delete" });
    }
    return res
      .status(200)
      .json({ success: true, message: "Advocate profile removed." });
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: error.message, error });
  }
};
